package com.test.ipathnertest.modelclasses

import com.google.gson.annotations.Expose

class GetEntriesResponse(
        @Expose val status : Int,
        @Expose val data : List<List<Entry>>
)

class Entry(
        @Expose val id : String,
        @Expose val body : String,
        @Expose val da : Long,
        @Expose val dm : Long
)