package com.test.ipathnertest

import android.app.Application
import android.util.Log

class App: Application() {

    companion object{
        lateinit var networkManager : NetworkManager
    }

    override fun onCreate() {
        super.onCreate()
        Log.e("app", "onCreate")
        networkManager = NetworkManager()
    }
}