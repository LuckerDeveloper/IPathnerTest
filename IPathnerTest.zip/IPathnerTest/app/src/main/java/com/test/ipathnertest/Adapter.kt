package com.test.ipathnertest

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.test.ipathnertest.modelclasses.Entry

class Adapter : RecyclerView.Adapter<RecyclerView.ViewHolder>(){

    var listOfEntries : List<Entry> = mutableListOf()

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val itemView = LayoutInflater.from(parent.context).inflate(R.layout.entry_item, parent, false)
        return EntryViewHolder(itemView)
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        holder as EntryViewHolder
        holder.timeTextView.text = listOfEntries.get(position).dm.toString()
        holder.bodyTextView.text = listOfEntries.get(position).body.toString()
    }

    override fun getItemCount(): Int {
        return listOfEntries.size
    }

    class EntryViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {

        val timeTextView = itemView.findViewById<TextView>(R.id.time_text_view)
        val bodyTextView = itemView.findViewById<TextView>(R.id.body_text_view)
    }

}