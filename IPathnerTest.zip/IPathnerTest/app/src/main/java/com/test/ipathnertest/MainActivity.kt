package com.test.ipathnertest

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.TextView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.test.ipathnertest.modelclasses.Entry
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class MainActivity : AppCompatActivity() {

    val networkManager by lazy { NetworkManager() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val recyclerView = findViewById<RecyclerView>(R.id.recycler_view)
        recyclerView.layoutManager = LinearLayoutManager(this)
        val adapter = Adapter()
        adapter.listOfEntries=mockList()
        recyclerView.adapter = Adapter()
    }

    fun mockList() : List<Entry>{
        val list = mutableListOf<Entry>()
        for (i in 0..5){
            val entry = Entry("id$i", "some text and big big big big big some text"
            ,System.currentTimeMillis(), System.currentTimeMillis())
            list.add(entry)
        }
        return list
    }
}

