package com.test.ipathnertest

import android.util.Log
import com.test.ipathnertest.modelclasses.AddEntryResponse
import com.test.ipathnertest.modelclasses.GetEntriesResponse
import com.test.ipathnertest.modelclasses.NewSessionResponse
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class NetworkManager {

    val TAG = "NetworkManager"
    lateinit var session: String
    private val networkService = NetworkService()

    init {
        initSession()
    }

    fun getEntries(){
        networkService.getJsonApi()
                .getEntries("get_entries", session)
                .enqueue(object : Callback<GetEntriesResponse>{
                    override fun onResponse(call: Call<GetEntriesResponse>, response: Response<GetEntriesResponse>) {
                        val getEntriesResponse = response.body()
                        val listOfEntries = getEntriesResponse!!.data.get(0)
                        Log.e(TAG, "size = ${listOfEntries.size}")
                        Log.e(TAG, "id = ${listOfEntries.get(0).id}")
                    }

                    override fun onFailure(call: Call<GetEntriesResponse>, t: Throwable) {
                        Log.e(TAG, t.toString())
                    }
                })
    }

    fun addEntry(body : String){
        networkService.getJsonApi()
                .addEntry("add_entry", session, body)
                .enqueue(object : Callback<AddEntryResponse>{
                    override fun onResponse(call: Call<AddEntryResponse>, response: Response<AddEntryResponse>) {
                        val addEntryResponse = response.body()
                        val id = addEntryResponse?.data?.id
                        Log.e(TAG, "add Entry id: $id")
                        getEntries()
                    }

                    override fun onFailure(call: Call<AddEntryResponse>, t: Throwable) {
                        Log.e(TAG, t.toString())
                    }

                })
    }

    private fun initSession(){
        networkService.getJsonApi()
                .getPostWithID("new_session")
                .enqueue(object : Callback<NewSessionResponse> {
            override fun onResponse(call: Call<NewSessionResponse>, response: Response<NewSessionResponse>) {
                val newSessionResponse  = response.body()
                session= newSessionResponse?.data?.session!!
                Log.e(TAG, "session: $session")
                addEntry("hello world")
            }

            override fun onFailure(call: Call<NewSessionResponse>, t: Throwable) {
                Log.e(TAG, t.toString())
            }
        })
    }


}